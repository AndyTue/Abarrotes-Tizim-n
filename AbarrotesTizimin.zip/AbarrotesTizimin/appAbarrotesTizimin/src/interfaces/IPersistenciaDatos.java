package interfaces;

import java.util.ArrayList;
import modelo.Cliente;
import modelo.Producto;

/**
 * Esta interfaz define los métodos para la persistencia de datos.
 */
public interface IPersistenciaDatos {

    /**
     * Guarda la lista de clientes.
     *
     * @param clientes la lista de clientes a guardar
     */
    public void guardarClientes(ArrayList<Cliente> clientes);

    /**
     * Carga la lista de clientes almacenada.
     *
     * @return la lista de clientes cargada
     */
    public ArrayList<Cliente> cargarClientes();

    /**
     * Guarda la lista de productos.
     *
     * @param productos la lista de productos a guardar
     */
    public void guardarProductos(ArrayList<Producto> productos);

    /**
     * Carga la lista de productos almacenada.
     *
     * @return la lista de productos cargada
     */
    public ArrayList<Producto> cargarProductos();

}