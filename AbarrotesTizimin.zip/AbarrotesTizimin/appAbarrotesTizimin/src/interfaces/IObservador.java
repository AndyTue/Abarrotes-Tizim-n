package interfaces;

/**
 * Esta interfaz define el método para actualizar un observador.
 */
public interface IObservador {

    /**
     * Actualiza el observador.
     */
    public void actualizar();

}