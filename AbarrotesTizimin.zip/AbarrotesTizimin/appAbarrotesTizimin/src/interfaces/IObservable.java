package interfaces;

/**
 * Esta interfaz define el método para notificar a todos los observadores.
 */
public interface IObservable {

    /**
     * Notifica a todos los observadores.
     */
    public void notificarTodos();

}