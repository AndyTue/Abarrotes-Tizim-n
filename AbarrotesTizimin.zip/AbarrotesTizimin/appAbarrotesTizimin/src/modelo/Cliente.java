package modelo;

import interfaces.IObservador;

/**
 * La clase Cliente representa a un cliente en el sistema.
 * Implementa la interfaz IObservador para recibir notificaciones.
 */
public class Cliente implements IObservador{
    private String id; // Identificador del cliente
    private String nombres; // Nombres del cliente
    private String apellidoPaterno; // Apellido paterno del cliente
    private String apellidoMaterno; // Apellido materno del cliente
    private Double puntosObtenidos; // Puntos obtenidos por el cliente
    private Direccion direccion; // Dirección del cliente
    private Long telefono; // Número de teléfono del cliente

    /**
     * Constructor de la clase Cliente con todos los campos.
     *
     * @param nombres         los nombres del cliente
     * @param apellidoPaterno el apellido paterno del cliente
     * @param apellidoMaterno el apellido materno del cliente
     * @param puntosObtenidos los puntos obtenidos por el cliente
     * @param direccion       la dirección del cliente
     * @param telefono        el número de teléfono del cliente
     */
    public Cliente(String nombres, String apellidoPaterno, String apellidoMaterno, Double puntosObtenidos, Direccion direccion, Long telefono) {
        this.nombres = nombres;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.puntosObtenidos = puntosObtenidos;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    /**
     * Constructor de la clase Cliente sin puntos obtenidos.
     *
     * @param nombres         los nombres del cliente
     * @param apellidoPaterno el apellido paterno del cliente
     * @param apellidoMaterno el apellido materno del cliente
     * @param direccion       la dirección del cliente
     * @param telefono        el número de teléfono del cliente
     */
    public Cliente(String nombres, String apellidoPaterno, String apellidoMaterno, Direccion direccion, Long telefono) {
        this.nombres = nombres;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    /**
     * Constructor de la clase Cliente con todos los campos, incluyendo el identificador.
     *
     * @param id              el identificador del cliente
     * @param nombres         los nombres del cliente
     * @param apellidoPaterno el apellido paterno del cliente
     * @param apellidoMaterno el apellido materno del cliente
     * @param puntosObtenidos los puntos obtenidos por el cliente
     * @param direccion       la dirección del cliente
     * @param telefono        el número de teléfono del cliente
     */
    public Cliente(String id, String nombres, String apellidoPaterno, String apellidoMaterno, Double puntosObtenidos, Direccion direccion, Long telefono) {
        this.id = id;
        this.nombres = nombres;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.puntosObtenidos = puntosObtenidos;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    /**
     * Constructor de la clase Cliente solo con el identificador.
     *
     * @param id el identificador del cliente
     */
    public Cliente(String id) {
        this.id = id;
    }


    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id

                = id;
    }

    public String getNombres() {
        return this.nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidoPaterno() {
        return this.apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return this.apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public Double getPuntosObtenidos() {
        return this.puntosObtenidos;
    }

    public void setPuntosObtenidos(Double puntosObtenidos) {
        this.puntosObtenidos = puntosObtenidos;
    }

    public Direccion getDireccion() {
        return this.direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    public Long getTelefono() {
        return this.telefono;
    }

    public void setTelefono(Long telefono) {
        this.telefono = telefono;
    }

    /**
     * Método de la interfaz IObservador para recibir y procesar una actualización.
     */
    @Override
    public void actualizar(){
        System.out.println("Mensaje para " + this.telefono + ":");
        System.out.println("Estimado " + this.apellidoPaterno + " " + this.apellidoMaterno + " " + this.nombres +" ID: " + this.id +  ", tiene " + this.puntosObtenidos + " puntos para usar en Abarrotes Tizimín");
    }

}