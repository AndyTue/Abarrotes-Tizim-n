package modelo;

import java.util.ArrayList;

/**
 * La clase Ticket representa un ticket de compra generado a partir de una Compra.
 */
public class Ticket {
    private Compra compra; // La compra asociada al ticket
    private String nombreTienda = "Abarrotes Tizimín"; // Nombre de la tienda
    private String fecha_hora; // Fecha y hora de la compra
    private String nombreCliente; // Nombre del cliente
    private String idCliente; // ID del cliente
    private Double puntosCompra; // Puntos obtenidos en la compra
    private Double importeProductos; // Importe total de los productos
    private Double descuento; // Descuento aplicado
    private Double importeFinal; // Importe final a pagar
    private Double pago; // Monto pagado por el cliente
    private Double cambio; // Cambio entregado al cliente
    private Double puntosTotales; // Puntos totales acumulados por el cliente
    private ArrayList<Producto> productos = new ArrayList<>(); // Lista de productos comprados

    /**
     * Constructor de la clase Ticket que recibe una instancia de Compra.
     *
     * @param compra la compra asociada al ticket
     */
    public Ticket(Compra compra) {
        this.compra = compra;
        this.fecha_hora = compra.getFecha_hora();
        this.nombreCliente = compra.getCliente().getApellidoPaterno() + " " + compra.getCliente().getApellidoMaterno()+ " " + compra.getCliente().getNombres();
        this.idCliente = compra.getCliente().getId();
        this.importeProductos = compra.getImporteProductos();
        this.descuento = compra.getDescuento();
        this.importeFinal = compra.getImporteFinal();
        this.pago = compra.getPago();
        this.cambio = compra.getCambio();
        this.puntosCompra = compra.getPuntosGenerados();
        this.puntosTotales = compra.getCliente().getPuntosObtenidos();
        this.productos.addAll(compra.getProductos());
    }

    public Compra getCompra() {
        return this.compra;
    }

    public String getNombreTienda() {
        return this.nombreTienda;
    }

    public void setNombreTienda(String nombreTienda) {
        this.nombreTienda = nombreTienda;
    }

    public String getFecha_hora() {
        return this.fecha_hora;
    }

    public void setFecha_hora(String fecha_hora) {
        this.fecha_hora = fecha_hora;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public Double getPuntosCompra() {
        return puntosCompra;
    }

    public void setPuntosCompra(Double puntosCompra) {
        this.puntosCompra = puntosCompra;
    }

    public Double getImporteProductos() {
        return importeProductos;
    }

    public void setImporteProductos(Double importeProductos) {
        this.importeProductos = importeProductos;
    }

    public Double getDescuento() {
        return descuento;
    }

    public void setDescuento(Double descuento) {
        this.descuento = descuento;
    }

    public Double getImporteFinal() {
        return importeFinal;
    }

    public void setImporteFinal(Double importeFinal) {
        this.importeFinal = importeFinal;
    }

    public Double getPago() {
        return pago;
    }

    public void setPago(Double pago) {
        this.pago = pago;
    }

    public Double getCambio() {


        return cambio;
    }

    public void setCambio(Double cambio) {
        this.cambio = cambio;
    }

    public Double getPuntosTotales() {
        return puntosTotales;
    }

    public void setPuntosTotales(Double puntosTotales) {
        this.puntosTotales = puntosTotales;
    }

    public ArrayList<Producto> getProductos() {
        return productos;
    }

    public void setProductos(ArrayList<Producto> productos) {
        this.productos = productos;
    }

    public String getIdCliente() {
        return this.idCliente;
    }
}
