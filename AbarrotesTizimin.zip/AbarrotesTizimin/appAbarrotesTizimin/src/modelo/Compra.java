package modelo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * La clase Compra representa una compra realizada por un cliente.
 */
public class Compra {
    private String fecha_hora; // Fecha y hora de la compra
    private Double importeProductos; // Importe total de los productos
    private Double descuento; // Descuento aplicado a la compra
    private Double importeFinal; // Importe final de la compra
    private Double pago; // Pago realizado por el cliente
    private Double cambio; // Cambio entregado al cliente
    private ArrayList<Producto> productos; // Lista de productos comprados
    private Cliente cliente; // Cliente que realizó la compra
    private Double puntosGenerados; // Puntos generados por la compra

    /**
     * Constructor de la clase Compra.
     *
     * @param iProductos     el importe total de los productos
     * @param descuento      el descuento aplicado a la compra
     * @param importeFinal   el importe final de la compra
     * @param pago           el pago realizado por el cliente
     * @param cambio         el cambio entregado al cliente
     * @param productos      la lista de productos comprados
     * @param cliente        el cliente que realizó la compra
     * @param puntosGenerados los puntos generados por la compra
     */
    public Compra(Double iProductos, Double descuento, Double importeFinal, Double pago, Double cambio, ArrayList<Producto> productos, Cliente cliente, Double puntosGenerados) {
        this.fecha_hora = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
        this.importeProductos = iProductos;
        this.descuento = descuento;
        this.importeFinal = importeFinal;
        this.pago = pago;
        this.cambio = cambio;
        this.productos = new ArrayList<>(productos);
        this.cliente = cliente;
        this.puntosGenerados = puntosGenerados;
    }

    public String getFecha_hora() {
        return this.fecha_hora;
    }

    public void setFecha_hora(String fecha_hora) {
        this.fecha_hora = fecha_hora;
    }

    public Double getImporteProductos() {
        return this.importeProductos;
    }

    public void setImporteProductos(Double importeProductos) {
        this.importeProductos = importeProductos;
    }

    public Double getDescuento() {
        return this.descuento;
    }

    public void setDescuento(Double descuento) {
        this.descuento = descuento;
    }

    public Double getImporteFinal() {
        return this.importeFinal;
    }

    public void setImporteFinal(Double importeFinal) {
        this.importeFinal = importeFinal;
    }

    public Double getPago() {
        return this.pago;
    }

    public void setPago(Double pago) {
        this.pago = pago;
    }

    public Double getCambio() {
        return this.cambio;
    }

    public void setCambio(Double cambio) {
        this.cambio = cambio;
    }

    public ArrayList<Producto> getProductos() {
        return this.productos;
    }

    public void setProductos(ArrayList<Producto> productos) {
        this.productos = productos;
    }

    public Cliente getCliente() {
        return this.cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Double getPuntosGenerados() {
        return this.puntosGenerados;
    }

    public void setPuntosGenerados(Double puntosGenerados) {
        this.puntosGenerados = puntosGenerados;
    }
}
