package modelo;

/**
 * La clase Producto representa un producto en el sistema.
 */
public class Producto {
    private String nombre; // Nombre del producto
    private String id; // ID del producto
    private Double cantidad; // Cantidad disponible del producto
    private Double precioProveedor; // Precio de compra del proveedor
    private Double precioVenta; // Precio de venta al cliente
    private Integer puntosOtorga; // Puntos otorgados al comprar el producto

    /**
     * Constructor de la clase Producto que recibe solo el ID del producto.
     *
     * @param id el ID del producto
     */
    public Producto(String id) {
        this.id = id;
    }

    /**
     * Constructor de la clase Producto.
     *
     * @param nombre          el nombre del producto
     * @param id              el ID del producto
     * @param cantidad        la cantidad disponible del producto
     * @param precioProveedor el precio de compra del proveedor
     * @param precioVenta     el precio de venta al cliente
     * @param puntosOtorga    los puntos otorgados al comprar el producto
     */
    public Producto(String nombre, String id, Double cantidad, Double precioProveedor, Double precioVenta, Integer puntosOtorga) {
        this.nombre = nombre;
        this.id = id;
        this.cantidad = cantidad;
        this.precioProveedor = precioProveedor;
        this.precioVenta = precioVenta;
        this.puntosOtorga = puntosOtorga;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Double getCantidad() {
        return this.cantidad;
    }

    public void setCantidad(Double cantidad) {
        this.cantidad = cantidad;
    }

    public Double getPrecioProveedor() {
        return this.precioProveedor;
    }

    public void setPrecioProveedor(Double precioProveedor) {
        this.precioProveedor = precioProveedor;
    }

    public Double getPrecioVenta() {
        return this.precioVenta;
    }

    public void setPrecioVenta(Double precioVenta) {
        this.precioVenta = precioVenta;
    }

    public Integer getPuntosOtorga() {
        return this.puntosOtorga;
    }

    public void setPuntosOtorga(Integer puntosOtorga) {
        this.puntosOtorga = puntosOtorga;
    }

    @Override
    public String toString() {
        return "Producto{" +
                "nombre=" + nombre +
                ", id=" + id +
                ", cantidad=" + cantidad +
                ", precioProveedor=" + precioProveedor +
                ", precioVenta=" + precioVenta +
                ", puntosOtorga=" + puntosOtorga +
                '}';
    }
}
