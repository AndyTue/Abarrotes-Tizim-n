package modelo;

/**
 * La clase Direccion representa la dirección de un cliente.
 */
public class Direccion {
    private Integer calle; // Número de la calle
    private String no_casa; // Número de la casa o departamento
    private String colonia; // Nombre de la colonia
    private Integer codigoPostal; // Código postal
    private String ciudad; // Nombre de la ciudad
    private String estado; // Nombre del estado

    /**
     * Constructor de la clase Direccion.
     *
     * @param calle        el número de la calle
     * @param no_casa      el número de la casa o departamento
     * @param colonia      el nombre de la colonia
     * @param codigoPostal el código postal
     * @param ciudad       el nombre de la ciudad
     * @param estado       el nombre del estado
     */
    public Direccion(Integer calle, String no_casa, String colonia, Integer codigoPostal, String ciudad, String estado) {
        this.calle = calle;
        this.no_casa = no_casa;
        this.colonia = colonia;
        this.codigoPostal = codigoPostal;
        this.ciudad = ciudad;
        this.estado = estado;
    }

    public Integer getCalle() {
        return this.calle;
    }

    public void setCalle(Integer calle) {
        this.calle = calle;
    }

    public String getNo_casa() {
        return this.no_casa;
    }

    public void setNo_casa(String no_casa) {
        this.no_casa = no_casa;
    }

    public String getColonia() {
        return this.colonia;
    }

    public void setColonia(String colonia) {
        this.colonia = colonia;
    }

    public Integer getCodigoPostal() {
        return this.codigoPostal;
    }

    public void setCodigoPostal(Integer codigoPostal) {
        this.codigoPostal = codigoPostal;
    }

    public String getCiudad() {
        return this.ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getEstado() {
        return this.estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return estado + ", " + ciudad  + ", colonia: " + colonia + " calle: " + calle + ", no_casa: " + no_casa +  ", C.P. " + codigoPostal ;
    }
}
