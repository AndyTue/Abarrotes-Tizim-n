package controlador;

import java.util.ArrayList;
import modelo.Compra;
import modelo.Producto;

/**
 * Esta clase es el controlador para gestionar las compras.
 */
public class ControladorCompra {
    private static ControladorCompra instance;
    private ArrayList<Compra> listaCompras = new ArrayList<>();
    private ArrayList<Producto> listaArticulos = new ArrayList<>();

    /**
     * Método para obtener la instancia única del controlador compra.
     * Si no existe una instancia previa, crea una nueva y la devuelve.
     * @return La instancia del ControladorCompra.
     */
    public static ControladorCompra getInstance() {
        if (instance == null)
            instance = new ControladorCompra();

        return instance;
    }

    /**
     * Método para obtener la lista de artículos.
     * @return La lista de artículos.
     */
    public ArrayList<Producto> getListaArticulos() {
        return this.listaArticulos;
    }

    /**
     * Método para limpiar la lista de compra, eliminando todos los artículos.
     */
    public void limpiarListaCompra() {
        this.listaArticulos.clear();
    }

    /**
     * Método para agregar un artículo a la lista de compra.
     * Verifica si el artículo existe y si hay suficiente cantidad en el inventario.
     * Si es así, actualiza la cantidad en el inventario y agrega el artículo a la lista de compra.
     * @param producto El producto a agregar.
     * @param peticion La cantidad solicitada del producto.
     * @return Un código de mensaje que indica el resultado de la operación:
     *         0 - No se pudo realizar la operación.
     *         1 - El producto no existe.
     *         2 - No hay suficiente cantidad del producto en el inventario.
     *         4 - El artículo se agregó correctamente.
     */
    public int agregarArticuloCompra(Producto producto, Double peticion) {
        int mensaje = 0; // no se pudo realizar
        boolean suficiente = true;
        boolean existe = false;

        if (ControladorProducto.getInstance().existeProducto(producto)) { // si existe
            existe = true;
            Producto productoInventario = ControladorProducto.getInstance().regresarProducto(producto);

            if (ControladorProducto.getInstance().existeSuficiente(productoInventario, peticion)) { // si tiene suficiente
                suficiente = true;
                productoInventario.setCantidad(productoInventario.getCantidad() - peticion);
                ControladorProducto.getInstance().modificarProducto(productoInventario);

                producto.setCantidad(1.);
                producto = ControladorProducto.getInstance().regresarProducto(producto);

                Producto productoCompra = new Producto(productoInventario.getNombre(), productoInventario.getId(),
                        peticion, productoInventario.getPrecioProveedor(), productoInventario.getPrecioVenta(),
                        productoInventario.getPuntosOtorga());
                this.listaArticulos.add(productoCompra);
            } else {
                suficiente = false;
            }
        } else {
            existe = false;
        }

        if (!existe)
            mensaje = 1; // no existe producto
        else if (existe & !suficiente)
            mensaje = 2; // no suficiente
        else if (existe & suficiente)
            mensaje = 4; // se agrego

        return mensaje;
    }

    /**
     * Método para devolver los artículos de la lista de compra al inventario.
     * Recorre la lista de artículos, incrementa la cantidad en el inventario y modifica el producto.
     * Luego, limpia la lista de compra.
     */
    public void regresarArticulosInventario() {
        for (int i = 0; i < listaArticulos.size(); i++) {
            String id = listaArticulos.get(i).getId();
            Producto producto = new Producto(id);

            Double cantidad = ControladorProducto.getInstance().regresarCantidad(producto);

            producto = listaArticulos.get(i);

            Double newCantidad = producto.getCantidad() + cantidad;
            producto.setCantidad(newCantidad);
            ControladorProducto.getInstance().modificarProducto(producto);
        }

        limpiarListaCompra();
    }

    /**
     * Método para calcular el total de la lista de compra.
     * Recorre la lista de artículos y suma el precio total de cada artículo.
     * @return El total de la lista de compra.
     */
    public Double totalListaCompra() {
        Double total = 0.;

        for (int i = 0; i < listaArticulos.size(); i++) {
            total = total + (listaArticulos.get(i).getCantidad() * listaArticulos.get(i).getPrecioVenta());
        }

        return total;
    }

    /**
     * Método para calcular los puntos generados por la lista de compra.
     * Recorre la lista de artículos y suma los puntos otorgados por cada artículo.
     * @return Los puntos generados por la lista de compra.
     */
    public Double puntosGenerados() {
        Double puntos = 0.;

        for (int i = 0; i < listaArticulos.size(); i++) {
            puntos = puntos + (listaArticulos.get(i).getCantidad() * listaArticulos.get(i).getPuntosOtorga());
        }

        return puntos;
    }

    /**
     * Método para calcular el descuento basado en la cantidad de puntos.
     * @param puntos La cantidad de puntos acumulados.
     * @return El descuento calculado.
     */
    public Double descuento(Integer puntos) {
        Double descuento = 0.;
        Double totalLista = totalListaCompra();

        switch (puntos) {
            case 0:
                descuento = totalLista * 0;
                break;
            case 200:
                descuento = totalLista * 0.03;
                break;
            case 400:
                descuento = totalLista * 0.06;
                break;
            case 600:
                descuento = totalLista * 0.09;
                break;
            case 800:
                descuento = totalLista * 0.12;
                break;
            case 1000:
                descuento = totalLista * 0.15;
                break;
        }

        return descuento;
    }

    /**
     * Método para calcular el importe total de la lista de compra, considerando el descuento.
     * @param puntos La cantidad de puntos acumulados.
     * @return El importe total calculado.
     */
    public Double importeTotal(Integer puntos) {
        Double importeTotal = totalListaCompra() - descuento(puntos);
        return importeTotal;
    }
}
