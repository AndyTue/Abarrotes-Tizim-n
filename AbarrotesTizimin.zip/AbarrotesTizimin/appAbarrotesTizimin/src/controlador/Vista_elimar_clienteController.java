package controlador;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import modelo.Cliente;

/**
 * Controlador para la vista de eliminación de cliente.
 */
public class Vista_elimar_clienteController implements Initializable {

    @FXML
    private AnchorPane AP_eliminar_cliente;
    @FXML
    private TextField TXF_Id_cliente;
    @FXML
    private Button BTN_salir;
    @FXML
    private Button BTN_eliminar;
    @FXML
    private Label LB_mensaje;
    @FXML
    private Button BTN_buscar;
    @FXML
    private Label LB_telefono;
    @FXML
    private Label LB_apellido_paterno;
    @FXML
    private Label LB_nombre;
    @FXML
    private Label LB_apellido_materno;
    @FXML
    private Label LB_ciudad;
    @FXML
    private Label LB_calle;
    @FXML
    private Label LB_estado;
    @FXML
    private Label LB_colonia;
    @FXML
    private Label LB_codigo_postal;
    @FXML
    private Label LB_num_casa;

    private String id;

    /**
     * Inicializa el controlador.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Deshabilitar el botón de eliminar al iniciar
        this.BTN_eliminar.setDisable(true);
    }

    @FXML
    private void salir(ActionEvent event) {
        // Cierra la ventana
        ((Stage)AP_eliminar_cliente.getScene().getWindow()).close();
    }

    @FXML
    private void eliminar(ActionEvent event) {
        // Crear un cliente auxiliar para luego eliminarlo
        Cliente clientent = new Cliente(id);
        ControladorCliente.getInstance().eliminarCliente(ControladorCliente.getInstance().regresarCliente(clientent));

        // Deshabilitar el botón de eliminar
        this.BTN_eliminar.setDisable(true);

        // Mostrar un mensaje indicando que el cliente ha sido eliminado correctamente
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText(null);
        alert.setTitle("Éxito");
        alert.setContentText("Cliente eliminado");
        alert.showAndWait();

        // Establecer los campos de texto en null
        this.LB_nombre.setText(null);
        this.LB_apellido_paterno.setText(null);
        this.LB_apellido_materno.setText(null);
        this.LB_calle.setText(null);
        this.LB_ciudad.setText(null);
        this.LB_codigo_postal.setText(null);
        this.LB_colonia.setText(null);
        this.LB_estado.setText(null);
        this.LB_num_casa.setText(null);
        this.LB_telefono.setText(null);
    }

    @FXML
    private void buscar(ActionEvent event) {
        // Guardar el ID en una variable
        String ID = this.TXF_Id_cliente.getText();

        // Revisar que el campo de texto no esté vacío
        if (this.TXF_Id_cliente.getText() == null || this.TXF_Id_cliente.getText().trim().isEmpty()) {
            // Mostrar un mensaje de error si el campo está vacío
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Inténtelo de nuevo");
            alert.setContentText("Llene el campo de texto");
            alert.showAndWait();
        } else {
            // Crear un nuevo cliente auxiliar con solo el ID
            Cliente cliente = new Cliente(ID);

            // Revisar si el cliente buscado existe
            if (ControladorCliente.getInstance().existeCliente(cliente)) {
                // Si existe, obtener el cliente completo
                cliente = ControladorCliente.getInstance().regresarCliente(cliente);
                id = ID;

                // Mostrar la información del cliente en los campos de texto
                this.LB_nombre.setText(cliente.getNombres());
                this.LB_apellido_paterno.setText(cliente.getApellidoPaterno());
                this.LB_apellido_materno.setText(cliente.getApellidoMaterno());
                this.LB_calle.setText(String.valueOf(cliente.getDireccion().getCalle()));
                this.LB_ciudad.setText(cliente.getDireccion().getCiudad());
                this.LB_codigo_postal.setText(String.valueOf(cliente.getDireccion().getCodigoPostal()));
                this.LB_colonia.setText(cliente.getDireccion().getColonia());
                this.LB_estado.setText(cliente.getDireccion().getEstado());
                this.LB_num_casa.setText(cliente.getDireccion().getNo_casa());
                this.LB_telefono.setText(String.valueOf(cliente.getTelefono()));

                this.BTN_eliminar.setDisable(false);
            } else {
                // Si el cliente no existe, mostrar un mensaje de error
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setTitle("Inténtelo de nuevo");
                alert.setContentText("El cliente no existe");
                alert.showAndWait();

                // Deshabilitar el botón de eliminar
                this.BTN_eliminar.setDisable(true);

                // Establecer los campos de texto en null
                this.LB_nombre.setText(null);
                this.LB_apellido_paterno.setText(null);
                this.LB_apellido_materno.setText(null);
                this.LB_calle.setText(null);
                this.LB_ciudad.setText(null);
                this.LB_codigo_postal.setText(null);
                this.LB_colonia.setText(null);
                this.LB_estado.setText(null);
                this.LB_num_casa.setText(null);
                this.LB_telefono.setText(null);
            }
        }
    }
}
