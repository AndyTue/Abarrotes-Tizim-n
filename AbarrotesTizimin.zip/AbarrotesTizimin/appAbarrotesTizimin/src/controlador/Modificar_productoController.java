package controlador;

import java.net.URL;
import java.util.InputMismatchException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import modelo.Producto;

/**
 * Controlador de la vista "Modificar_producto.fxml".
 */
public class Modificar_productoController implements Initializable {

    @FXML
    private AnchorPane AP_modificar_producto;
    @FXML
    private TextField TXF_nombre;
    @FXML
    private TextField TXF_Id;
    @FXML
    private TextField TXF_cantidad;
    @FXML
    private TextField TXF_precio_provedor;
    @FXML
    private TextField TXF_prcio_venta;
    @FXML
    private TextField TXF_puntos;
    @FXML
    private Button BTN_salir;
    @FXML
    private Button BTN_guardar;
    @FXML
    private Label LB_id_producto;
    @FXML
    private Button BTN_buscar;

    private String idProducto;

    /**
     * Inicializa el controlador después de que se haya cargado el archivo FXML.
     * @param url La ubicación utilizada para resolver rutas relativas de recursos.
     * @param rb Los recursos utilizados para localizar el archivo FXML.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Deshabilitar los campos de texto y el botón "Guardar"
        this.BTN_guardar.setDisable(true);
        this.TXF_cantidad.setDisable(true);
        this.TXF_nombre.setDisable(true);
        this.TXF_prcio_venta.setDisable(true);
        this.TXF_precio_provedor.setDisable(true);
        this.TXF_puntos.setDisable(true);
    }

    @FXML
    private void salir(ActionEvent event) {
        // Cerrar la ventana actual
        ((Stage) AP_modificar_producto.getScene().getWindow()).close();
    }

    @FXML
    private void guardar(ActionEvent event) {
        try {
            // Obtener los valores de los campos de texto
            String nombre = this.TXF_nombre.getText();
            Double cantidad = Double.parseDouble(this.TXF_cantidad.getText());
            Double precioProveedor = Double.parseDouble(this.TXF_precio_provedor.getText());
            Double precioVenta = Double.parseDouble(this.TXF_prcio_venta.getText());
            Integer puntosOtorga = Integer.parseInt(this.TXF_puntos.getText());

            // Crear un objeto Producto con los valores ingresados
            Producto producto = new Producto(nombre, idProducto, cantidad, precioProveedor, precioVenta, puntosOtorga);
            ControladorProducto.getInstance().modificarProducto(producto);

            // Deshabilitar el botón "Guardar"
            this.BTN_guardar.setDisable(true);

            // Mostrar una alerta de éxito
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setHeaderText(null);
            alert.setTitle("Éxito");
            alert.setContentText("Producto modificado");
            alert.showAndWait();

            // Limpiar los campos de texto y el ID del producto
            this.TXF_cantidad.setText(null);
            this.TXF_nombre.setText(null);
            this.TXF_prcio_venta.setText(null);
            this.TXF_precio_provedor.setText(null);
            this.TXF_puntos.setText(null);
            this.idProducto = null;

            // Deshabilitar los campos de texto
            this.TXF_cantidad.setDisable(true);
            this.TXF_nombre.setDisable(true);
            this.TXF_prcio_venta.setDisable(true);
            this.TXF_precio_provedor.setDisable(true);
            this.TXF_puntos.setDisable(true);

        } catch (NumberFormatException e) {
            // Mostrar una alerta de error si los datos ingresados son incorrectos
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Inténtelo de nuevo");
            alert.setContentText("Ingrese correctamente los datos");
            alert.showAndWait();
        }
    }

    @FXML
    private void buscar(ActionEvent event) {
        // Leer el valor del campo de texto de ID
        String ID = this.TXF_Id.getText();

        // Verificar si el campo de texto está vacío
        if (this.TXF_Id.getText() == null || this.TXF_Id.getText().trim().isEmpty()) {
            // Mostrar una alerta de error si el campo está vacío
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Inténtelo de nuevo");
            alert.setContentText("Llene el cuadro de texto");
            alert.showAndWait();
        } else {
            // Crear un objeto Producto con el ID ingresado
            Producto producto = new Producto(ID);
            if (ControladorProducto.getInstance().existeProducto(producto)) {
                producto = ControladorProducto.getInstance().regresarProducto(producto);

                // Llenar los campos de texto con los valores del producto encontrado
                this.TXF_cantidad.setText(String.valueOf(producto.getCantidad()));
                this.TXF_nombre.setText(producto.getNombre());
                this.TXF_prcio_venta.setText(String.valueOf(producto.getPrecioVenta()));
                this.TXF_precio_provedor.setText(String.valueOf(producto.getPrecioProveedor()));
                this.TXF_puntos.setText(String.valueOf(producto.getPuntosOtorga()));
                this.idProducto = producto.getId();

                // Habilitar el botón "Guardar"
                this.BTN_guardar.setDisable(false);

                // Habilitar los campos de texto
                this.TXF_cantidad.setDisable(false);
                this.TXF_nombre.setDisable(false);
                this.TXF_prcio_venta.setDisable(false);
                this.TXF_precio_provedor.setDisable(false);
                this.TXF_puntos.setDisable(false);

            } else {
                // Mostrar una alerta de error si el producto no existe
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setTitle("Inténtelo de nuevo");
                alert.setContentText("El producto no existe");
                alert.showAndWait();

                // Deshabilitar el botón "Guardar" y limpiar los campos de texto
                this.BTN_guardar.setDisable(true);
                this.TXF_cantidad.setText(null);
                this.TXF_nombre.setText(null);
                this.TXF_prcio_venta.setText(null);
                this.TXF_precio_provedor.setText(null);
                this.TXF_puntos.setText(null);
                this.idProducto = null;

                // Deshabilitar los campos de texto
                this.TXF_cantidad.setDisable(true);
                this.TXF_nombre.setDisable(true);
                this.TXF_prcio_venta.setDisable(true);
                this.TXF_precio_provedor.setDisable(true);
                this.TXF_puntos.setDisable(true);
            }
        }
    }
}
