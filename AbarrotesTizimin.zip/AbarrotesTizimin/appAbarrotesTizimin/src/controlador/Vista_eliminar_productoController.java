package controlador;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import modelo.Producto;

/**
 * Controlador para la vista de eliminación de producto.
 */
public class Vista_eliminar_productoController implements Initializable {

    @FXML
    private TextField TXF_Id;
    @FXML
    private Button BTN_salir;
    @FXML
    private Label LB_nombre;
    @FXML
    private Label LB_no_encontrado;
    @FXML
    private Label LB_cantidad;
    @FXML
    private Label LB_precio_provedor;
    @FXML
    private Label LB_precio_venta;
    @FXML
    private Label LB_puntos;
    @FXML
    private Button BTN_buscar;
    @FXML
    private Button BTN_eliminar;
    @FXML
    private AnchorPane AP_eliminar_producto;

    private String idProducto;

    /**
     * Inicializa el controlador.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.BTN_eliminar.setDisable(true);
    }

    @FXML
    private void salir(ActionEvent event) {
        // Cierra la ventana
        ((Stage)AP_eliminar_producto.getScene().getWindow()).close();
    }

    @FXML
    private void buscar(ActionEvent event) {
        // Lectura de los campos de texto
        String ID = this.TXF_Id.getText();

        // Verificar si algún campo de texto está vacío
        if (this.TXF_Id.getText() == null || this.TXF_Id.getText().trim().isEmpty()) {
            // Mostrar un mensaje de error si el campo está vacío
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Inténtelo de nuevo");
            alert.setContentText("Llene el cuadro de texto");
            alert.showAndWait();
        } else {
            // Crear un nuevo objeto Producto con el ID
            Producto producto = new Producto(ID);

            // Verificar si el producto existe
            if (ControladorProducto.getInstance().existeProducto(producto)) {
                // Si existe, obtener el producto completo
                producto = ControladorProducto.getInstance().regresarProducto(producto);

                // Mostrar la información del producto en las etiquetas
                this.LB_nombre.setText(producto.getNombre());
                this.LB_precio_provedor.setText(String.valueOf(producto.getPrecioProveedor()));
                this.LB_precio_venta.setText(String.valueOf(producto.getPrecioVenta()));
                this.LB_puntos.setText(String.valueOf(producto.getPuntosOtorga()));
                this.LB_cantidad.setText(String.valueOf(producto.getCantidad()));
                this.idProducto = producto.getId();
                this.BTN_eliminar.setDisable(false);
            } else {
                // Si el producto no existe, mostrar un mensaje de error
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setTitle("Inténtelo de nuevo");
                alert.setContentText("El producto no existe");
                alert.showAndWait();

                // Deshabilitar el botón de eliminar
                this.BTN_eliminar.setDisable(true);

                // Establecer las etiquetas en null
                this.LB_nombre.setText(null);
                this.LB_precio_provedor.setText(null);
                this.LB_precio_venta.setText(null);
                this.LB_puntos.setText(null);
                this.LB_cantidad.setText(null);
                this.idProducto = null;
            }
        }
    }

    @FXML
    private void eliminar(ActionEvent event) {
        // Crear un objeto Producto con el ID del producto a eliminar
        Producto producto = new Producto(idProducto);

        // Eliminar el producto
        ControladorProducto.getInstance().eliminarProducto(ControladorProducto.getInstance().regresarProducto(producto));

        // Deshabilitar el botón de eliminar
        this.BTN_eliminar.setDisable(true);

        // Mostrar un mensaje de confirmación
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText(null);
        alert.setTitle("Éxito");
        alert.setContentText("Producto eliminado");
        alert.showAndWait();

        // Establecer el campo de texto en null
        this.TXF_Id.setText(null);

        // Establecer las etiquetas en null
        this.LB_nombre.setText(null);
        this.LB_precio_provedor.setText(null);
        this.LB_precio_venta.setText(null);
        this.LB_puntos.setText(null);
        this.LB_cantidad.setText(null);
        this.idProducto = null;
    }
}
