package controlador;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import modelo.Cliente;
import modelo.Direccion;

/**
 * Controlador para la vista de agregar cliente.
 */
public class Vista_agregar_clienteController implements Initializable {

    @FXML
    private AnchorPane AP_agregarCliente;
    @FXML
    private Label LB_nombre;
    @FXML
    private Label LB_apellido_1;
    @FXML
    private Label LB_ciudad;
    @FXML
    private Label LB_calle;
    @FXML
    private Label LB_num_casa;
    @FXML
    private TextField TXF_nombre;
    @FXML
    private TextField TXF_apellido_1;
    @FXML
    private TextField TXF_ciudad;
    @FXML
    private TextField TXF_calle;
    @FXML
    private TextField TXF_num_casa;
    @FXML
    private Button BTN_salir;
    @FXML
    private Button BTN_guardar;
    @FXML
    private Label LB_apellido_2;
    @FXML
    private TextField TXF_apellido_2;
    @FXML
    private Label LB_estado;
    @FXML
    private TextField TXF_estado;
    @FXML
    private Label LB_telefono;
    @FXML
    private TextField TXF_telefono;
    @FXML
    private Label LB_codigo_postal;
    @FXML
    private Label LB_colonia;
    @FXML
    private TextField TXF_colonia;
    @FXML
    private TextField TXF_codigo_postal;
    @FXML
    private Label LB_mensaje;

    /**
     * Inicializa el controlador.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // No se requiere ninguna inicialización especial
    }

    @FXML
    private void salir(ActionEvent event) {
        // Cerrar la ventana actual
        ((Stage) AP_agregarCliente.getScene().getWindow()).close();
    }

    @FXML
    private void guardar(ActionEvent event) {
        // Comprobar que todos los campos de texto estén completos
        if (this.TXF_apellido_1.getText() == null || this.TXF_apellido_1.getText().trim().isEmpty()
                || this.TXF_apellido_2.getText() == null || this.TXF_apellido_2.getText().trim().isEmpty()
                || this.TXF_calle.getText() == null || this.TXF_calle.getText().trim().isEmpty()
                || this.TXF_ciudad.getText() == null || this.TXF_ciudad.getText().trim().isEmpty()
                || this.TXF_codigo_postal.getText() == null || this.TXF_codigo_postal.getText().trim().isEmpty()
                || this.TXF_colonia.getText() == null || this.TXF_colonia.getText().trim().isEmpty()
                || this.TXF_estado.getText() == null || this.TXF_estado.getText().trim().isEmpty()
                || this.TXF_nombre.getText() == null || this.TXF_nombre.getText().trim().isEmpty()
                || this.TXF_num_casa.getText() == null || this.TXF_num_casa.getText().trim().isEmpty()
                || this.TXF_telefono.getText() == null || this.TXF_telefono.getText().trim().isEmpty()) {

            // Mostrar mensaje de error si algún campo está vacío
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Inténtelo de nuevo");
            alert.setContentText("Llene los cuadros de texto");
            alert.showAndWait();

        } else {
            // Todos los campos están completos

            try {
                // Obtener los datos de los campos de texto
                String nombres = this.TXF_nombre.getText();
                String apellidoPaterno = this.TXF_apellido_1.getText();
                String apellidoMaterno = this.TXF_apellido_2.getText();
                Long telefono = Long.parseLong(this.TXF_telefono.getText());
                Integer calle = Integer.parseInt(this.TXF_calle.getText());
                String no_casa = this.TXF_num_casa.getText();
                String colonia = this.TXF_colonia.getText();
                Integer codigoPostal = Integer.parseInt(this.TXF_codigo_postal.getText());
                String ciudad = this.TXF_ciudad.getText();
                String estado = this.TXF_estado.getText();
                String id = ControladorCliente.getInstance().generarId();

                // Crear una dirección y un cliente
                Direccion direccion = new Direccion(calle, no_casa, colonia, codigoPostal, ciudad, estado);
                Cliente cliente = new Cliente(id, nombres, apellidoPaterno, apellidoMaterno, 0., direccion, telefono);

                if (ControladorCliente.getInstance().existeClienteNom(cliente)) {

                    // El cliente ya existe
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText(null);
                    alert.setTitle("Inténtelo de nuevo");
                    alert.setContentText("El Cliente ya existe");
                    alert.showAndWait();

                } else {

                    // Agregar el nuevo cliente
                    ControladorCliente.getInstance().agregarCliente(cliente);

                    // Mostrar mensaje de éxito
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setHeaderText(null);
                    alert.setTitle("Éxito");
                    alert.setContentText("Cliente agregado al inventario");
                    alert.showAndWait();

                    // Limpiar los campos de texto
                    this.TXF_nombre.setText(null);
                    this.TXF_apellido_1.setText(null);
                    this.TXF_apellido_2.setText(null);
                    this.TXF_calle.setText(null);
                    this.TXF_ciudad.setText(null);
                    this.TXF_codigo_postal.setText(null);
                    this.TXF_colonia.setText(null);
                    this.TXF_estado.setText(null);
                    this.TXF_num_casa.setText(null);
                    this.TXF_telefono.setText(null);

                }
            } catch (NumberFormatException e) {
                // Error en la conversión de datos
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setTitle("Inténtelo de nuevo");
                alert.setContentText("Ingrese correctamente los datos");
                alert.showAndWait();
            }
        }
    }

}
