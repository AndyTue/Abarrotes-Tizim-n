package controlador;

import java.util.ArrayList;
import modelo.Producto;

/**
 * Esta clase es el controlador para gestionar los productos.
 * Implementa la interfaz IProductosDAO.
 */
public class ControladorProducto{
    private static ControladorProducto instance;
    private static ArrayList<Producto> listaProductos = new ArrayList<>();
    private PersistorDatos persistencia = PersistorDatos.getInstance();

    /**
     * Método para obtener la instancia única del controlador de productos.
     * Si no existe una instancia previa, crea una nueva y la devuelve.
     * @return La instancia del ControladorProducto.
     */
    public static ControladorProducto getInstance() {
        if (instance == null)
            instance = new ControladorProducto();

        return instance;
    }

    /**
     * Método para agregar un producto a la lista de productos.
     * @param producto El producto a agregar.
     */

    public void agregarProducto(Producto producto) {
        listaProductos.add(producto);
        persistencia.guardarProductos(listaProductos);
    }

    /**
     * Método para modificar un producto en la lista de productos.
     * @param producto El producto modificado.
     */

    public void modificarProducto(Producto producto) {
        for (int i = 0; i < listaProductos.size(); i++) {
            if (producto.getId().equals(listaProductos.get(i).getId()))
                listaProductos.set(i, producto);
        }
        persistencia.guardarProductos(listaProductos);
    }

    /**
     * Método para eliminar un producto de la lista de productos.
     * @param producto El producto a eliminar.
     */

    public void eliminarProducto(Producto producto) {
        listaProductos.remove(producto);
        persistencia.guardarProductos(listaProductos);
    }

    /**
     * Método para obtener la lista de productos.
     * @return La lista de productos.
     */

    public ArrayList<Producto> getListaProductos() {
        return ControladorProducto.listaProductos;
    }

    /**
     * Método para establecer la lista de productos.
     * @param listaProductos La nueva lista de productos.
     */
    public void setListaProductos(ArrayList<Producto> listaProductos) {
        ControladorProducto.listaProductos.clear();
        ControladorProducto.listaProductos.addAll(listaProductos);
    }

    /**
     * Método para verificar si hay suficiente cantidad de un producto.
     * Compara la cantidad solicitada con la cantidad del producto.
     * @param producto El producto a verificar.
     * @param peticion La cantidad solicitada.
     * @return true si hay suficiente cantidad, false en caso contrario.
     */
    public boolean existeSuficiente(Producto producto, Double peticion) {
        int resultado = Double.compare(peticion, producto.getCantidad());
        return resultado <= 0;
    }

    /**
     * Método para verificar si un producto existe en la lista de productos.
     * @param producto El producto a verificar.
     * @return true si el producto existe, false en caso contrario.
     */
    public boolean existeProducto(Producto producto) {
        boolean existe = false;
        for (int i = 0; i < listaProductos.size(); i++) {
            if (producto.getId().equals(listaProductos.get(i).getId())) {
                existe = true;
            }
        }
        return existe;
    }

    /**
     * Método para obtener un producto de la lista de productos.
     * @param producto El producto a buscar.
     * @return El producto encontrado, o null si no se encuentra.
     */
    public Producto regresarProducto(Producto producto) {
        Producto encontrado = null;
        for (int i = 0; i < listaProductos.size(); i++) {
            if (producto.getId().equals(listaProductos.get(i).getId())) {
                encontrado = listaProductos.get(i);
            }
        }
        return encontrado;
    }

    /**
     * Método para obtener la cantidad de un producto de la lista de productos.
     * @param producto El producto a buscar.
     * @return La cantidad del producto encontrado, o 0 si no se encuentra.
     */
    public Double regresarCantidad(Producto producto) {
        Double cantidad = 0.;
        for (int i = 0; i < listaProductos.size(); i++) {
            if (producto.getId().equals(listaProductos.get(i).getId())) {
                cantidad = listaProductos.get(i).getCantidad();
            }
        }
        return cantidad;
    }
}
