package controlador;

import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * Clase principal que inicia la aplicación y carga la vista del menú principal.
 */
public class Main extends Application {

    /**
     * Método principal que inicia la aplicación.
     * @param primaryStage El escenario principal de la aplicación.
     */
    @Override
    public void start(Stage primaryStage) {
        // Cargar la lista de productos y clientes desde el persistor de datos
        ControladorProducto.getInstance().setListaProductos(PersistorDatos.getInstance().cargarProductos());
        ControladorCliente.getInstance().setListaClientes(PersistorDatos.getInstance().cargarClientes());

        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Main.class.getResource("/vista/VistaMenuPrincipal.fxml"));
            Pane ventana = (Pane) loader.load();

            Scene scene = new Scene(ventana);

            primaryStage.setResizable(false);
            primaryStage.setTitle("Menú principal");
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }

    /**
     * Método principal de la aplicación.
     * @param args Los argumentos de la línea de comandos.
     */
    public static void main(String[] args) {
        launch(args);
    }

    /**
     * Método que se ejecuta al cerrar la aplicación y devuelve los artículos al inventario.
     */
    @Override
    public void stop() {
        ControladorCompra.getInstance().regresarArticulosInventario();
    }
}
