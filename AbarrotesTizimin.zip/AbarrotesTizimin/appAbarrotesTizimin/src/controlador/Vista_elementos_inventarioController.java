package controlador;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import modelo.Producto;

/**
 * Controlador para la vista de elementos de inventario.
 */
public class Vista_elementos_inventarioController implements Initializable {

    @FXML
    private AnchorPane AP_ver_Inventario;
    @FXML
    private TableView<Producto> TB_ver_inventario;
    @FXML
    private TableColumn<?, ?> CLM_id;
    @FXML
    private TableColumn<?, ?> CLM_nombre;
    @FXML
    private TableColumn<?, ?> CLM_cantidad;
    @FXML
    private TableColumn<?, ?> CLM_puntos;
    @FXML
    private TableColumn<?, ?> CLM_precio_proveedor;
    @FXML
    private TableColumn<?, ?> CLM_jprecio_venta;

    // Lista observable de productos para mostrar en la tabla
    protected ObservableList<Producto> listaProductos = FXCollections.observableArrayList(ControladorProducto.getInstance().getListaProductos());

    /**
     * Inicializa el controlador.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Configurar las propiedades de las columnas de la tabla
        this.CLM_id.setCellValueFactory(new PropertyValueFactory("id"));
        this.CLM_nombre.setCellValueFactory(new PropertyValueFactory("nombre"));
        this.CLM_cantidad.setCellValueFactory(new PropertyValueFactory("cantidad"));
        this.CLM_puntos.setCellValueFactory(new PropertyValueFactory("puntosOtorga"));
        this.CLM_precio_proveedor.setCellValueFactory(new PropertyValueFactory("precioProveedor"));
        this.CLM_jprecio_venta.setCellValueFactory(new PropertyValueFactory("precioVenta"));

        // Cargar la lista de productos en la tabla
        listaProductos.setAll(ControladorProducto.getInstance().getListaProductos());
        this.TB_ver_inventario.setItems(listaProductos);
    }
}
