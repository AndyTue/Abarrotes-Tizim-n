package controlador;

import java.util.ArrayList;
import java.util.Random;
import modelo.Cliente;
import interfaces.IObservable;

/**
 * Esta clase es el controlador para gestionar los clientes.
 */
public class ControladorCliente implements IObservable{

    private static ControladorCliente instancia;
    private static ArrayList<Cliente> listaClientes = new ArrayList<>();
    private PersistorDatos persistencia = PersistorDatos.getInstance();

    /**
     * Método para obtener la instancia única del controlador cliente.
     * Si no existe una instancia previa, crea una nueva y la devuelve.
     * @return La instancia del ControladorCliente.
     */
    public static ControladorCliente getInstance(){

        if(instancia == null)
            instancia = new ControladorCliente();

        return instancia;

    }

    /**
     * Método para obtener la lista de clientes.
     * @return La lista de clientes.
     */

    public ArrayList<Cliente> getListaClientes() {
        return this.listaClientes;
    }

    /**
     * Método para agregar un cliente a la lista de clientes.
     * Genera un ID para el cliente y lo guarda en la lista de clientes.
     * Además, guarda la lista de clientes en la persistencia de datos.
     * @param cliente El cliente a agregar.
     */

    public void agregarCliente(Cliente cliente){
        cliente.setId(generarId());
        listaClientes.add(cliente);
        persistencia.guardarClientes(listaClientes);
    }

    /**
     * Método para modificar un cliente en la lista de clientes.
     * Busca el cliente por su ID y actualiza sus datos en la lista.
     * También guarda la lista de clientes en la persistencia de datos.
     * @param cliente El cliente a modificar.
     */

    public void modificarCliente(Cliente cliente){
        for(int i = 0; i < listaClientes.size(); i++){
            if(cliente.getId().equals(listaClientes.get(i).getId()))
                listaClientes.set(i, cliente);
        }
        persistencia.guardarClientes(listaClientes);
    }

    /**
     * Método para eliminar un cliente de la lista de clientes.
     * Remueve el cliente de la lista y guarda la lista actualizada en la persistencia de datos.
     * @param cliente El cliente a eliminar.
     */

    public void eliminarCliente(Cliente cliente){
        listaClientes.remove(cliente);
        persistencia.guardarClientes(listaClientes);
    }

    /**
     * Método para establecer la lista de clientes.
     * Reemplaza la lista actual de clientes por la lista proporcionada.
     * @param listaClientes La nueva lista de clientes.
     */
    public void setListaClientes(ArrayList<Cliente> listaClientes){

        ControladorCliente.listaClientes.clear();
        ControladorCliente.listaClientes.addAll(listaClientes);

    }

    /**
     * Método para generar un ID único para un cliente.
     * Genera un número aleatorio y verifica si ya existe en la lista de clientes.
     * Si el número ya existe, genera uno nuevo hasta obtener uno único.
     * @return El ID generado.
     */
    public String generarId(){
        boolean existe;
        String id = numeroRandom();
        do{
            existe = false;
            for(int i=0; i < listaClientes.size();i++){
                if(id.equals(listaClientes.get(i).getId())){
                    existe = true;
                }
            }
            if(existe){
                id = numeroRandom();
            }
        }while(existe);
        return id;
    }

    /**
     * Método para generar un número aleatorio de 7 dígitos como String.
     * @return El número aleatorio generado.
     */
    private String numeroRandom(){
        Random numero = new Random();
        Integer n = numero.nextInt(9999999-1000000+1) + 1000000;
        String ns = String.valueOf(n);
        return ns;
    }

    /**
     * Método para notificar a todos los clientes observadores.
     * Invoca al método "actualizar" de cada cliente en la lista.
     */
    @Override
    public void notificarTodos(){
        for (Cliente cliente : listaClientes) {
            cliente.actualizar();
        }
    }

    /**
     * Método para verificar la existencia de un cliente en la lista de clientes.
     * @param cliente El cliente a verificar.
     * @return true si el cliente existe, false en caso contrario.
     */
    public boolean existeCliente(Cliente cliente){
        boolean existencia=false;

        for(int i=0; i<listaClientes.size(); i++){
            if(cliente.getId().equals(listaClientes.get(i).getId())){
                existencia = true;
            }
        }

        return existencia;
    }

    /**
     * Método para verificar si existe otro cliente con el mismo nombre y apellidos en la lista de clientes.
     * @param cliente El cliente a verificar.
     * @return true si no existe otro cliente con el mismo nombre y apellidos, false en caso contrario.
     */
    public boolean existeClienteNom(Cliente cliente){
        boolean existencia=false;

        for(int i=0; i<listaClientes.size(); i++){
            if (cliente.getNombres().equals(listaClientes.get(i).getNombres()) || cliente.getApellidoPaterno().equals(listaClientes.get(i).getApellidoPaterno()) || cliente.getApellidoMaterno().equals(listaClientes.get(i).getApellidoMaterno())) {
                existencia = true;
            }
        }

        return existencia;
    }

    /**
     * Método para obtener un cliente de la lista de clientes por su ID.
     * @param cliente El cliente a buscar.
     * @return El cliente encontrado o null si no se encuentra en la lista.
     */
    public Cliente regresarCliente(Cliente cliente){

        Cliente encontrado = null;

        for(int i=0; i<listaClientes.size(); i++){

            if(cliente.getId().equals(listaClientes.get(i).getId())){
                encontrado = listaClientes.get(i);
            }
        }

        return encontrado;
    }
}
